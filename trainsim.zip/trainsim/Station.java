/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

/**
 *
 * @author Ryan
 */
public class Station {
    private int stationID,randomOnMin,RandomOnMax,RandomOffMin,RandomOffMax,TicketPrice;
    private boolean freight;
    
    public Station(int stationID, int randomOnMin, int RandomOnMax, int RandomOffMin, int RandomOffMax, int TicketPrice, boolean freight) {
        this.stationID = stationID;
        this.randomOnMin = randomOnMin;
        this.RandomOnMax = RandomOnMax;
        this.RandomOffMin = RandomOffMin;
        this.RandomOffMax = RandomOffMax;
        this.TicketPrice = TicketPrice;
        this.freight = freight;
    }

    public int getStationID() {
        return stationID;
    }

    public int getRandomOnMin() {
        return randomOnMin;
    }

    public int getRandomOnMax() {
        return RandomOnMax;
    }

    public int getRandomOffMin() {
        return RandomOffMin;
    }

    public int getRandomOffMax() {
        return RandomOffMax;
    }

    public int getTicketPrice() {
        return TicketPrice;
    }
    
    public boolean getFreight(){
        return freight;
    }
    
    @Override
    public String toString() {
        return("stationID: " + stationID + " randomOnMin: " + randomOnMin + " randomOnMax: " + 
                RandomOnMax + " randomOffMin: " + RandomOffMin + " randomOffMax: " + RandomOffMax + 
                " ticketPrice: " + TicketPrice + " freight: " + freight);
    }
}
