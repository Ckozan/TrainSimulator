/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class Tracks {

    private ArrayList<Track> allTracks = new ArrayList<>();

    private Tracks() {

    }

    public Tracks(ResultSet rs) throws SQLException {
        boolean startHub = false, endHub = false;
        int i = 0;
            while (rs.next()) {
                startHub = false;
                endHub = false;
                int trackID = rs.getInt("TrackID");
                int startTime = rs.getInt("StartTime");
                int endTime = rs.getInt("EndTime");
                int startLoc = rs.getInt("StartLocStationID");
                if(startLoc == 0){
                    startLoc = rs.getInt("StartLocHubID");
                    startHub = true;
                }
                int endLoc = rs.getInt("EndLocStationID");
                if(endLoc == 0){
                    endLoc = rs.getInt("EndLocHubID");
                    endHub = true;
                }
                int length = rs.getInt("Length");
                int speedLimit = rs.getInt("SpeedLimit");
                
           

                allTracks.add(new Track(trackID,startTime,endTime,startLoc,endLoc,length,speedLimit,startHub,endHub));
                //System.out.println(allTracks.get(i));
                  i++;
            }
    }

    public Track getTrackByIndex(int index) {
        if(index <= allTracks.size()-1 && index >=0){
            return allTracks.get(index);
        }
        return null;
    }

    public Track getTrackById(int id){
        for(int i =0; i<allTracks.size();i++){
            if(allTracks.get(i).getTrackID()== id){
                return(allTracks.get(i));
            }
        }
        return null;
    }

    private void addTrack(Track t){
        allTracks.add(t);
    }

    public Tracks getTracksByStartStation(int stationID){
        Tracks temp = new Tracks();

        for(int i=0; i<allTracks.size();i++){
            if(allTracks.get(i).getStartLocID() == stationID && allTracks.get(i).isStartHub() == false){
                temp.addTrack(allTracks.get(i));
            }
        }
        return(temp);
    }

    public Tracks getAllTracksConnectedToHub(){
        Tracks temp = new Tracks();

        for(int i=0; i<allTracks.size();i++){
            if((allTracks.get(i).isStartHub() == true) || (allTracks.get(i).isEndHub() == true)){
                temp.addTrack(allTracks.get(i));
            }
        }
        return(temp);
    }
    
    public int getSize(){
        return allTracks.size();
    }
    
    public void deleteById(int id){
        for(int i =0; i<allTracks.size();i++){
            if(allTracks.get(i).getTrackID()== id){
                allTracks.remove(i);
            }
        }
    }
}