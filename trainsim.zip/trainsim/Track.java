/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

/**
 *
 * @author Ryan
 */
public class Track {
    int trackID,startTime,endTime,startLocID,endLocID,length,speedLimit;
    int [] weather = new int[24];
    boolean startHub,endHub;

    public Track(int trackID, int startTime, int endTime, int startLocID, int endLocID, int length, int speedLimit, boolean startHub, boolean endHub) {
        this.trackID = trackID;
        this.startTime = startTime;
        this.endTime = endTime;
        this.startLocID = startLocID;
        this.endLocID = endLocID;
        this.length = length;
        this.speedLimit = speedLimit;
        this.startHub = startHub;
        this.endHub = endHub;
    }

    public int getTrackID() {
        return trackID;
    }

    public int getStartTime() {
        return startTime;
    }

    public int getEndTime() {
        return endTime;
    }

    public int getStartLocID() {
        return startLocID;
    }

    public int getEndLocID() {
        return endLocID;
    }

    public int getLength() {
        return length;
    }

    public int getSpeedLimit() {
        return speedLimit;
    }

    public int[] getWeather() {
        return weather;
    }

    public boolean isStartHub() {
        return startHub;
    }

    public boolean isEndHub() {
        return endHub;
    }

    public void setWeather(int[] weather) {
        this.weather = weather;
    }
    
    @Override
    public String toString() {
        return("trackID: "+ trackID+" startTime: "+startTime+" endTime: "+endTime+""
                + " startLocID: "+startLocID+" endLocID: "+endLocID+" length: "+length+" speedLimit: "+speedLimit 
                + " startHub: " + startHub + " endHub: " + endHub);
    }
}
