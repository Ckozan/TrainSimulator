/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

/**
 *
 * @author Ryan
 */
public class Dtable {
    private int[] idNum, time, prevLocId,waitTime;
    private boolean[] hub, prevLocHub, visited;
    private int startLoc;
    private boolean startLocHub;
    int numOfRows;
    
    public Dtable(int numOfHubsAndStations, int startLoc, boolean startLocHub,int startTime, Stations allStations,Hubs allHubs){
        this.startLoc = startLoc;
        this.startLocHub = startLocHub;
        numOfRows = numOfHubsAndStations;
        idNum = new int[numOfHubsAndStations];
        time = new int[numOfHubsAndStations];
        prevLocId = new int[numOfHubsAndStations];
        waitTime = new int[numOfHubsAndStations];
        hub = new boolean[numOfHubsAndStations];
        prevLocHub = new boolean[numOfHubsAndStations];
        visited = new boolean[numOfHubsAndStations];
        for(int i =0; i<numOfHubsAndStations;i++){
            if(i<allHubs.getSize()){
                idNum[i] = allHubs.getHubByIndex(i).getHubId();
                hub[i] = true;
                time[i] = -1;
                visited[i] = false;
            }
            else{
                idNum[i] = allStations.getStationByIndex(i-allHubs.getSize()).getStationID();
                hub[i] = false;
                time[i] = -1;
                visited[i] = false;
            }
            if(idNum[i] == startLoc && hub[i] == startLocHub){
                time[i] = startTime;
                visited[i] = true;
            }
        }
    }
    
    public void updateRow(int idNum, boolean hub, int time, int prevLocId, boolean prevLocHub, int waitTime){
        for(int i = 0; i<numOfRows;i++){
            if(this.idNum[i] == idNum && this.hub[i] == hub){
                if((this.time[i]<0 || this.time[i] > time) && visited[i] == false){
                    this.time[i] = time;
                    this.prevLocId[i] = prevLocId;
                    this.prevLocHub[i] = prevLocHub;
                    this.waitTime[i] = waitTime;
                }
                break;
            }
        }
    }
    
    public int[] getNextBestLoc(){
        int[] bestLoc = {0,0};
        int bestTime = 2000;
        int index = -1;
        
        for(int i = 0; i< numOfRows;i++){
            if(time[i]<bestTime && time[i]>0 && visited[i] == false){
                index = i;
                bestLoc[0]=idNum[i];
                if(hub[i] == true){
                    bestLoc[1] = 1;
                }
                else{
                    bestLoc[1] = 0;
                }
            }
        }
        if(index != -1){
            visited[index] = true;
        }
        return bestLoc;
    }
    
    public boolean notVisited(int idNum, boolean hub){
        for(int i = 0; i<numOfRows;i++){
            if(this.idNum[i] == idNum && this.hub[i] == hub && visited[i] == false){
                return true;
            }
        }
        return false;
    }
    
    public int getTimeAtLoc(int idNum, boolean hub){
        for(int i = 0; i<numOfRows;i++){
            if(this.idNum[i] == idNum && this.hub[i] == hub){
                return time[i];
            }
        }
        return 2000;
    }
    
    @Override
    public String toString() {
        String info = "\nstartLoc: " + startLoc + " startLocHub: " + startLocHub +
                "\nrowNum: idNum, hub, time, visited, prevLocId, prevLocHub, waitTime";
        for(int i = 0; i < numOfRows;i++){
            info += "\nrow" + i + ": " + idNum[i] + "," + hub[i] + "," + time[i] + ","+ visited[i] + 
                    "," + prevLocId[i] + "," + prevLocHub[i] + "," + waitTime[i];
        }
        return(info);
    }

    public int getStartLoc() {
        return startLoc;
    }

    public boolean isStartLocHub() {
        return startLocHub;
    }
    
    
}
