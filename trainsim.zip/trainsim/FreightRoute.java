/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

/**
 *
 * @author Ryan
 */
public class FreightRoute {
    private int routeId,startLocId,endLocId,startTime,timeArrived,timeAssigned;

    public FreightRoute(int routeId, int startLocId, int endLocId, int startTime) {
        this.routeId = routeId;
        this.startLocId = startLocId;
        this.endLocId = endLocId;
        this.startTime = startTime;
    }

    public int getRouteId() {
        return routeId;
    }

    public int getStartLocId() {
        return startLocId;
    }

    public int getEndLocId() {
        return endLocId;
    }

    public int getStartTime() {
        return startTime;
    }

    public int getTimeArrived() {
        return timeArrived;
    }

    public void setTimeArrived(int timeArrived) {
        this.timeArrived = timeArrived;
    }

    public int getTimeAssigned() {
        return timeAssigned;
    }

    public void setTimeAssigned(int timeAssigned) {
        this.timeAssigned = timeAssigned;
    }
    
    public int getPriorityValue(int timeArrivedAtStartLoc, int travelTime, int FreightCValue){
        if(timeArrivedAtStartLoc > startTime){
            return(timeArrivedAtStartLoc + FreightCValue);
        }
        return(startTime + (startTime-timeArrivedAtStartLoc));
    }
    
    @Override
    public String toString() {
        return("routeId: " + routeId + " startLocId: " + startLocId + " endLocId: " + 
                endLocId + " startTime: " + startTime + " TimeArrived: " + timeArrived + 
                " timeAssigned: " + timeAssigned);
    }
}
