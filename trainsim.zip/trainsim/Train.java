/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;
/**
 *
 * @author Ryan
 */
public class Train{
    private int trainID, homeHubID, capacityMax,capacityCurrent,TopSpeed,crewTime,TimeComplete, totalWaitTime,currentLoc;
    private boolean freight,currentLocHub;

    public Train(int trainID, int homeHubID, int capacityMax, int TopSpeed, boolean freight) {
        this.trainID = trainID;
        this.homeHubID = homeHubID;
        this.capacityMax = capacityMax;
        this.TopSpeed = TopSpeed;
        this.freight = freight;
        capacityCurrent = 0;
        TimeComplete = 0;
        totalWaitTime = 0;
        crewTime = 0;
        currentLoc=homeHubID;
        currentLocHub = true;
    }

    public int getTrainID() {
        return trainID;
    }

    public int getHomeHubID() {
        return homeHubID;
    }

    public int getCapacityMax() {
        return capacityMax;
    }

    public int getCapacityCurrent() {
        return capacityCurrent;
    }

    public int getTopSpeed() {
        return TopSpeed;
    }

    public boolean isFreight() {
        return freight;
    }

    public int getCrewTime() {
        return crewTime;
    }

    public void setCrewTime(int crewTime) {
        this.crewTime = crewTime;
    }
    
    public void setCapacityCurrent(int capacityCurrent) {
        this.capacityCurrent = capacityCurrent;
    }

    public int getTimeComplete() {
        return TimeComplete;
    }

    public void setTimeComplete(int TimeComplete) {
        this.TimeComplete = TimeComplete;
    }
    
    public void addWaitTime(int waitTime){
        totalWaitTime += waitTime;
    }
    
    @Override
    public String toString() {
        return("trainId: " + trainID + " homeHubId: " + homeHubID + " capacityMax: " + capacityMax + 
                " capacityCurrent: " + capacityCurrent + " topSpeed: " + TopSpeed + " crewTime: " + 
                crewTime + " timeComplete: " + TimeComplete + " totalWaitTime: " + totalWaitTime + " freight: " + freight);
    }

    public int getCurrentLoc() {
        return currentLoc;
    }

    public void setCurrentLoc(int currentLoc) {
        this.currentLoc = currentLoc;
    }

    public boolean isCurrentLocHub() {
        return currentLocHub;
    }

    public void setCurrentLocHub(boolean currentLocHub) {
        this.currentLocHub = currentLocHub;
    }
    
    
}
