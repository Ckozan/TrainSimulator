/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */
public class Routes {
    private ArrayList <FreightRoute> fRoutes = new ArrayList<>();
    private ArrayList <FreightRoute> fRoutesComplete = new ArrayList<>();
    private ArrayList <PassengerRoute> pRoutes = new ArrayList<>();
    private ArrayList <PassengerRoute> pRoutesComplete = new ArrayList<>();
    private int FreightCValue;
    
    public Routes(ResultSet freight, ResultSet passenger, ResultSet day, ResultSet config){
        int i = 0;
        try {               
        //parse day
        
        //parse config
        //config.first();
        //FreightCValue = config.getInt("CValue");
            //parse freight routes
            while (freight.next()) {
                int RouteID = freight.getInt("RouteID");
                int startLocId = freight.getInt("StartLocID");
                int endLocId = freight.getInt("EndLocID");
                int startTime = freight.getInt("StartTime");
                int repeating = freight.getInt("Repeating");
                int runDay = freight.getInt("RunDay");
                
                fRoutes.add(new FreightRoute(RouteID,startLocId,endLocId,startTime));
                //System.out.println(fRoutes.get(i));
                i++;
            }
            //parse passenger routes;
            i=0;
            while(passenger.next()){
                int routeId = passenger.getInt("RouteID");
               // int repeating = freight.getInt("Repeating");
               // int runDay = freight.getInt("RunDay");
                pRoutes.add(new PassengerRoute(routeId));
                ResultSet set = MySQL.connection.prepareStatement("select StopNumber,LocID,StartTime from Passenger_Route where active=1 AND RouteID=" + routeId).executeQuery();
                ArrayList<Integer> locId = new ArrayList<>();
                ArrayList<Integer> startTime = new ArrayList<>();
                while(set.next()){
                    locId.add(set.getInt("LocID"));
                    startTime.add(set.getInt("StartTime"));
                }
                pRoutes.get(i).addAllStops(locId, startTime);
                //System.out.println(pRoutes.get(i).toString());
                i++;
            }
        } catch (SQLException ex) {
            Logger.getLogger(Routes.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public ArrayList<Integer> getBestRoute(Train train, Dtable dTable){
        return null;
    }
    
    public void deleteFreightById(int id){
        for(int i =0; i<fRoutes.size();i++){
            if(fRoutes.get(i).getRouteId()== id){
                fRoutes.remove(i);
            }
        }
    }
    
    public void deletePassengerById(int id){
        for(int i =0; i<pRoutes.size();i++){
            if(pRoutes.get(i).getRouteID()== id){
                pRoutes.remove(i);
            }
        }
    }
    
    public int getNumOfFreightRoutes(){
        return fRoutes.size();
    }
    
    public int getNumOfPassengerRoutes(){
        return pRoutes.size();
    }
    
    public FreightRoute getFreightByIndex(int index){
        return fRoutes.get(index);
    }
    
    public PassengerRoute getPassengerByIndex(int index){
        return pRoutes.get(index);
    }
    
    public void freightRouteAssigned(int routeId, int timeAssigned, int timeArrived){
        for(int i =0; i<fRoutes.size();i++){
            if(fRoutes.get(i).getRouteId()== routeId){
                fRoutesComplete.add(fRoutes.get(i));
                fRoutes.get(i).setTimeArrived(timeArrived);
                fRoutes.get(i).setTimeAssigned(timeAssigned);
                fRoutes.remove(i);
            }
        }
    }
}
