/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class Hubs {
    private ArrayList <Hub> theHubs = new ArrayList<>();
    
    public Hubs(ResultSet rs)throws SQLException{
        int i =0;
        while(rs.next()){
            int hubID = rs.getInt("HubID");
            theHubs.add(new Hub(hubID));
            //System.out.println(theHubs.get(i));
            i++;
        }
    }
    
    public int getSize(){
        return theHubs.size();
    }
    
    public Hub getHubByIndex(int index) {
        if(index <= theHubs.size()-1 && index >=0){
            return theHubs.get(index);
        }
        return null;
    }

    public Hub getHubById(int id){
        for(int i =0; i<theHubs.size();i++){
            if(theHubs.get(i).getHubId()== id){
                return(theHubs.get(i));
            }
        }
        return null;
    }
}
