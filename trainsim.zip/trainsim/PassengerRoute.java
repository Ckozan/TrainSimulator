/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class PassengerRoute {
    int routeID,timeAssigned;
    ArrayList<Integer> locID,startTime,timeArrived,timeArrivedBC;

    public PassengerRoute(int routeID) {
        this.routeID = routeID;
        timeAssigned = 0;
    }
    
    public void addAllStops(ArrayList<Integer> location,ArrayList<Integer> time){
        locID = location;
        startTime = time;
    }

    public int getRouteID() {
        return routeID;
    }

    public int getLocIdOfStop(int stopNum) {
        return locID.get(stopNum);
    }

    public int getStartTimeOfStop(int stopNum) {
        return startTime.get(stopNum);
    }

    public int getTimeAssigned() {
        return timeAssigned;
    }

    public void setTimeAssigned(int timeAssigned) {
        this.timeAssigned = timeAssigned;
    }
    
    public void setNextTimeArrived(int time){
        timeArrived.add(time);
    }
        
    public void setTimeArrivedBC(ArrayList<Integer> BC){
        timeArrivedBC =BC;
    }
    
    public double getPriorityValue(int timeArrivedAtStartLoc, int travelTime){
        int waitTime = 0, theSlackTime = 0, stopsOnTime = 0, currentTime = timeArrivedAtStartLoc;
        
        if(timeArrivedAtStartLoc <= startTime.get(0)){
            stopsOnTime++;
            waitTime = startTime.get(0)-timeArrivedAtStartLoc;
            currentTime = startTime.get(0);
        }
        
        for(int i = 1; i<startTime.size();i++){
            currentTime += 30 + (timeArrivedBC.get(i)-startTime.get(i-1));
            if(currentTime <=startTime.get(i)){
                stopsOnTime++;
                theSlackTime += (startTime.get(i)-currentTime);
                currentTime = startTime.get(i);
            }
        }
        
        return ((startTime.size()/stopsOnTime)*(travelTime + waitTime + theSlackTime));
    }
    
    public int numOfStops(){
        return locID.size();
    }
    
    @Override
    public String toString() {
        String pRoute = "routeId: " + routeID + " timeAssigned: " + timeAssigned + 
                "\n stopNum: locID,startTime,timeArrivedBc,slackTime,timeArrived";
        
        for(int i = 0; i< locID.size();i++){
            pRoute += "\n Stop" + i + ": " + locID.get(i) + "," + startTime.get(i) + ","
                    + timeArrivedBC.get(i); //+  "," + timeArrived.get(i);
        }
        return(pRoute);
    }
}
