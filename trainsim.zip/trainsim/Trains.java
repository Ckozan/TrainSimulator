/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class Trains {
	
    private ArrayList<Train> theTrains = new ArrayList<>();
    
    private Trains() {
    	
    }
    
    public Trains(ResultSet rs) throws SQLException{
        int i = 0;
        while(rs.next()){
            int trainID = rs.getInt("TrainID");
            int isFreight = rs.getInt("Freight");
            int homeHubID = rs.getInt("HomeHubID");
            int capacity = rs.getInt("Capacity");
            int topSpeed = rs.getInt("TopSpeed");
            
            if(isFreight == 0){
                theTrains.add(new Train(trainID,homeHubID,capacity,topSpeed,false));
            }
            else{
                theTrains.add(new Train(trainID,homeHubID,capacity,topSpeed,true));
            }
            //System.out.println(theTrains.get(i));
            i++;
        }
    }
    
    private void addTrain(Train t){
        theTrains.add(t);
    }
    
    public Trains getTrainsForReroute(int time){
        Trains temp = new Trains();      
        
        for(int i=0; i<theTrains.size();i++){
            if(theTrains.get(i).getTimeComplete() <= time){
                temp.addTrain(theTrains.get(i));
            }
        }
        return temp;
    }
    
    public Train getTrainAtArrayLoc(int loc){
        if(loc <=(theTrains.size()-1) && loc >= 0){
        return theTrains.get(loc);
        }
        return null;
    }
    
    public Train getTrainByID(int id){
        for(int i = 0; i<theTrains.size();i++){
            if(theTrains.get(i).getTrainID() == id){
                return(theTrains.get(i));
            }
        }
        return null;
    }
    
    public int getSize(){
        return theTrains.size();
    }
    
    public void deleteById(int id){
        for(int i = 0; i<theTrains.size();i++){
            if(theTrains.get(i).getTrainID() == id){
                theTrains.remove(i);
            }
        }
    }
}
