/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

import java.io.File;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */
public class TrainSim {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        /*try {
        new InputReader(new File("C:/Users/Ryan/Desktop/Structure"));
        new InputReader(new File("C:/Users/Ryan/Desktop/Config"));
        new InputReader(new File("C:/Users/Ryan/Desktop/Maitenence"));
        new InputReader(new File("C:/Users/Ryan/Desktop/Repeatable Routes"));
        new InputReader(new File("C:/Users/Ryan/Desktop/Daily Routes"));
        } catch (SQLException ex) {
            Logger.getLogger(TrainSim.class.getName()).log(Level.SEVERE, null, ex);
        }*/

       MySQL connect = new MySQL("cis_375_schema", "root", "password");
        try {
        ResultSet rs = MySQL.connection.prepareStatement("SELECT * FROM `train` WHERE true").executeQuery();
        while(rs.next()) {
            int trainID = rs.getInt("TrainID");
            int isFreight = rs.getInt("Freight");
            int homeHubID = rs.getInt("HomeHubID");
            int capacity = rs.getInt("Capacity");
            int topSpeed = rs.getInt("TopSpeed");
            int isActive = rs.getInt("Active");
        }
        } catch (SQLException ex) {
            Logger.getLogger(TrainSim.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("Connected to database");
        
        routeManager.Initialize(0);
        routeManager.Baseline();
        for(int i = 0; i<1440;i++){
            routeManager.checkRouteComplete(i+1);
        }
    }
    
}
