/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

/**
 *
 * @author Ryan
 */
public class Hub {
    private int hubId;
    
    public Hub (int hubId){
        this.hubId = hubId;
    }
    
    public int getHubId(){
        return hubId;
    }
    
    @Override
    public String toString() {
        return("hubId: " + hubId);
    }
}
