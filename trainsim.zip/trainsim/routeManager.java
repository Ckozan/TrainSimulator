/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ryan
 */
public class routeManager {
    private static Tracks allTracks;
    private static Routes allRoutes;
    private static Trains allTrains;
    private static Stations allStations;
    private static Hubs allHubs;
    private static int numOfHubsAndStations, freightSpeed, passengerSpeed;
    private static Dtable[] bestPassengerRoutes,bestFreightRoutes;

    public static void Initialize(int day){
        int id,startDay,endDay,currentDay = day;
        try {
            //get all data from database for the day and store in correct places
            ResultSet set = MySQL.connection.prepareStatement("select * from Track where Active=1").executeQuery();
            allTracks = new Tracks(set);
            
            set = MySQL.connection.prepareStatement("select * from Station where Active=1").executeQuery();
            allStations = new Stations(set);
            
            set = MySQL.connection.prepareStatement("select * from Train where Active=1").executeQuery();
            allTrains = new Trains(set);
            
            set = MySQL.connection.prepareStatement("select * from Hub where Active=1").executeQuery();
            allHubs = new Hubs(set);
            
            ResultSet set1 = MySQL.connection.prepareStatement("select * from freight_route where Active=1").executeQuery();
            set = MySQL.connection.prepareStatement("select distinct RouteID,Repeating,RunDay from Passenger_Route where active=1").executeQuery();
            //ResultSet set2 = MySQL.connection.prepareStatement("select * from Day where DayID=" + currentDay).executeQuery();
            //ResultSet set3 = MySQL.connection.prepareStatement("select CValue from Config where 1").executeQuery();
            allRoutes = new Routes(set1,set,set1,set1);
            
            //get current day
            set = MySQL.connection.prepareStatement("select distinct StationID3,StartDay,EndDay from Maintenance where Active=1 AND StationID3 IS NOT NULL").executeQuery();
            while(set.next()){
                id = set.getInt("StationID3");
                startDay = set.getInt("StartDay");
                endDay = set.getInt("EndDay");
                if(currentDay >=startDay && currentDay<=endDay){
                    allStations.deleteById(id);
                }
            }
            
            set = MySQL.connection.prepareStatement("select distinct TrackID3,StartDay,EndDay from Maintenance where Active=1 AND TrackID3 IS NOT NULL").executeQuery();
            while(set.next()){
                id = set.getInt("StationID3");
                startDay = set.getInt("StartDay");
                endDay = set.getInt("EndDay");
                if(currentDay >=startDay && currentDay<=endDay){
                    allTracks.deleteById(id);
                }
            }
            
            set = MySQL.connection.prepareStatement("select distinct TrainID5,StartDay,EndDay from Maintenance where Active=1 AND TrainID5 IS NOT NULL").executeQuery();
            while(set.next()){
                id = set.getInt("StationID3");
                startDay = set.getInt("StartDay");
                endDay = set.getInt("EndDay");
                if(currentDay >=startDay && currentDay<=endDay){
                    allTrains.deleteById(id);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(routeManager.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println("initialize");
    }
    
    public static void Baseline(){
        //call baseline algorithm will speed for frieght and then passenger train, upload to database
        numOfHubsAndStations = allHubs.getSize() + allStations.getSize();
        bestFreightRoutes = baselineAlgorithm(true);
        bestPassengerRoutes = baselineAlgorithm(false);
        baselineFreightRoutes();
        baselinePassengerRoutes();
        //update database with baseline
        System.out.println("baseline");
    }
    
    public static void checkRouteComplete(int currentTime){
        //checks to see if any trains are available for another route
        boolean startWithPass = true;
        Train theTrain;
        if(freightSpeed > passengerSpeed){
            startWithPass = false;
        }
        for(int i = 0; i < 2; i++){
            if(startWithPass){
                for(int j = 0; j < allTrains.getSize();j++){
                    theTrain = allTrains.getTrainAtArrayLoc(j);
                    if(theTrain.getTimeComplete()<=currentTime && theTrain.isFreight() == false){
                        assignPassengerRoute(theTrain,currentTime);
                    }
                }
                startWithPass = false;
            }else{
                for(int j = 0; j < allTrains.getSize();j++){
                    theTrain = allTrains.getTrainAtArrayLoc(j);
                    if(theTrain.getTimeComplete()<=currentTime && theTrain.isFreight() == true){
                        assignFreightRoute(theTrain,currentTime);
                    }
                }
                startWithPass = true;
            }
        }
        //System.out.println("checkRouteComplete");
    }
    
    private static Dtable[] baselineAlgorithm(boolean freight){
        //calculates best route not accounting for timed track or weather
        int i = 0;
        Train train = allTrains.getTrainAtArrayLoc(i);
        while(train.isFreight() != freight){
            i++;
            train = allTrains.getTrainAtArrayLoc(i);
        }
        //System.out.println(train.getTopSpeed());
        double trackSpeedLimit = 0.0,trainSpeed = ((double)train.getTopSpeed())/60.00;
        trainSpeed = round(trainSpeed,2);
        if(freight){
            freightSpeed = train.getTopSpeed();
        }else{
            passengerSpeed = train.getTopSpeed();
        }
        int idNum,timeForTrack, timeToLocation;
        boolean hub;
        int[] nextLoc;
        Tracks allHubTracks = allTracks.getAllTracksConnectedToHub();
        Tracks stationTracks;
        Track theTrack; 
        Dtable[] bestRoutes = new Dtable[numOfHubsAndStations];
        for(i =0; i<numOfHubsAndStations;i++){
            if(i<allHubs.getSize()){
                idNum = allHubs.getHubByIndex(i).getHubId();
                hub = true;
            }
            else{
                idNum = allStations.getStationByIndex(i-allHubs.getSize()).getStationID();
                hub = false;
            }
            bestRoutes[i] = new Dtable(numOfHubsAndStations,idNum,hub,1,allStations,allHubs);
            do{
                timeToLocation = bestRoutes[i].getTimeAtLoc(idNum, hub);
                if(hub == false){
                    stationTracks = allTracks.getTracksByStartStation(idNum);
                    for(int j = 0; j< stationTracks.getSize();j++){
                        theTrack = stationTracks.getTrackByIndex(j);
                        if(bestRoutes[i].notVisited(theTrack.endLocID, theTrack.endHub)){
                            if(theTrack.speedLimit > 0){
                                trackSpeedLimit = round((double)theTrack.speedLimit/60.00,2);
                            }
                            if(trackSpeedLimit > trainSpeed || theTrack.speedLimit <= 0){
                                timeForTrack = roundUp(theTrack.length/trainSpeed);
                            }
                            else{
                                timeForTrack = roundUp(theTrack.length/trackSpeedLimit);
                            }
                            bestRoutes[i].updateRow(theTrack.endLocID, theTrack.endHub, timeToLocation+timeForTrack, idNum, hub, 0);
                        }
                    }
                    for(int j = 0; j< allHubTracks.getSize();j++){
                        theTrack = allHubTracks.getTrackByIndex(j);
                        if((theTrack.endLocID == idNum && theTrack.endHub == false) || (theTrack.startLocID == idNum && theTrack.startHub == false)){
                            if(theTrack.speedLimit > 0){
                                trackSpeedLimit = round((double)theTrack.speedLimit/60.00,2);
                            }
                            if(trackSpeedLimit > trainSpeed || theTrack.speedLimit <= 0){
                                timeForTrack = roundUp(theTrack.length/trainSpeed);
                            }
                            else{
                                timeForTrack = roundUp(theTrack.length/trackSpeedLimit);
                            }
                            if(theTrack.startLocID == idNum && theTrack.startHub == false){
                                bestRoutes[i].updateRow(theTrack.endLocID, theTrack.endHub, timeToLocation+timeForTrack, idNum, hub, 0);
                            }
                            else{
                                bestRoutes[i].updateRow(idNum, hub, timeToLocation+timeForTrack, theTrack.endLocID, theTrack.endHub, 0);
                            }
                        }
                    }
                }
                else{
                    for(int j = 0; j< allHubTracks.getSize();j++){
                        theTrack = allHubTracks.getTrackByIndex(j);
                        if((theTrack.endLocID == idNum && theTrack.endHub == true) || (theTrack.startLocID == idNum && theTrack.startHub == true)){
                            if(theTrack.speedLimit > 0){
                                trackSpeedLimit = round((double)theTrack.speedLimit/60.00,2);
                            }
                            if(trackSpeedLimit > trainSpeed || theTrack.speedLimit <= 0){
                                timeForTrack = roundUp(theTrack.length/trainSpeed);
                            }
                            else{
                                timeForTrack = roundUp(theTrack.length/trackSpeedLimit);
                            }
                            if(theTrack.startLocID == idNum && theTrack.startHub == true){
                                bestRoutes[i].updateRow(theTrack.endLocID, theTrack.endHub, timeToLocation+timeForTrack, idNum, hub, 0);
                            }
                            else{
                                bestRoutes[i].updateRow(idNum, hub, timeToLocation+timeForTrack, theTrack.endLocID, theTrack.endHub, 0);
                            }
                        }
                    }
                }
       
                nextLoc = bestRoutes[i].getNextBestLoc();
                idNum = nextLoc[0];
                if(nextLoc[1]==1){
                    hub = true;
                }
                else{
                    hub = false;
                }
            }while(idNum != 0);
            //System.out.println(bestRoutes[i].toString());
        }
        //System.out.println(bestRoutes[1].toString());
        return bestRoutes;
    }
    
    private static Dtable mainAlgorithm(Train train, int currentLoc, int currentTime,boolean isCurrentHub, int endLoc, boolean isEndHub){
        //calculates best route and if end location stops when end location is fully calculated
        
        return null;
    }
    
    private static double round(double value, int places){
        long factor = (long) Math.pow(10, places);
        value = value * factor;
        long tmp = Math.round(value);
        return(double)tmp/factor;
    }
    
    private static int roundUp(double value){
        int rounded = (int) Math.round(value);
        return (rounded+1);
    }
    
    private static void baselineFreightRoutes(){
        FreightRoute fRoute;
        ArrayList<Integer> deletes = new ArrayList<>();
        Dtable dTable;
        int time;
        String printMessage;
        for(int i = 0;i< allRoutes.getNumOfFreightRoutes();i++){
            fRoute = allRoutes.getFreightByIndex(i);
            for(int j = 0; j< bestFreightRoutes.length;j++){
                dTable = bestFreightRoutes[j];
                if(dTable.getStartLoc() == fRoute.getStartLocId() && dTable.isStartLocHub() == false){
                    if(dTable.notVisited(fRoute.getEndLocId(), false)){
                        deletes.add(fRoute.getRouteId());
                    }
                    else{
                        time = 60 + fRoute.getStartTime() + dTable.getTimeAtLoc(fRoute.getEndLocId(), false);
                        if(time>1440){
                            deletes.add(fRoute.getRouteId());
                        }
                    }
                }
            }
        }
        printMessage = "The following freight routes are being deleted from today's list for being impossible to complete: ";
        for(int i = 0; i< deletes.size();i++){
            printMessage += " Id" + deletes.get(i);
            allRoutes.deleteFreightById(i);
        }
        System.out.println(printMessage);
    }
    
    private static void baselinePassengerRoutes(){
        PassengerRoute pRoute;
        ArrayList<Integer> deletes = new ArrayList<>(), timeArrivedBC = new ArrayList<>();
        Dtable dTable;
        int time = 0, startStopId, startStopTime, endStopId, endStopTime;
        String printMessage;
        boolean notDeleted;
        for(int i = 0;i< allRoutes.getNumOfPassengerRoutes();i++){
            pRoute = allRoutes.getPassengerByIndex(i);
            //System.out.println("Route " + (i+1) + " stops: " + pRoute.numOfStops());
            timeArrivedBC = new ArrayList<>();
            notDeleted = true;
            for(int k = 1; k < pRoute.numOfStops();k++){
                startStopId = pRoute.getLocIdOfStop(k-1);
                startStopTime = pRoute.getStartTimeOfStop(k-1);
                endStopId = pRoute.getLocIdOfStop(k);
                endStopTime = pRoute.getStartTimeOfStop(k);
                for(int j = 0; j< bestPassengerRoutes.length;j++){
                    dTable = bestPassengerRoutes[j];
                    if(dTable.getStartLoc() == startStopId && dTable.isStartLocHub() == false){
                        if(dTable.notVisited(endStopId, false)){
                            if(notDeleted){
                                deletes.add(pRoute.getRouteID());
                                //System.out.println(pRoute.getRouteID());
                                notDeleted=false;
                            }
                        }
                        else{
                            if(k == 1){
                                time = startStopTime + 30;
                                timeArrivedBC.add(startStopTime);
                            }
                            time += dTable.getTimeAtLoc(endStopId, false);
                            timeArrivedBC.add(time);
                            if(time < endStopTime){
                                time = endStopTime;
                            }
                            time += 30;
                            if(time>1440){
                                if(notDeleted){
                                    deletes.add(pRoute.getRouteID());
                                    //System.out.println(pRoute.getRouteID());
                                    notDeleted=false;
                                }
                            }
                        }
                    }
                }
            }
            //System.out.println("stops: " + timeArrivedBC.size());
            //System.out.println(pRoute.toString());
            pRoute.setTimeArrivedBC(timeArrivedBC);
        }
        printMessage = "The following passenger routes are being deleted from today's list for being impossible to complete: ";
        for(int i = 0; i< deletes.size();i++){
            printMessage += " Id" + deletes.get(i);
            allRoutes.deletePassengerById(i);
        }
        System.out.println(printMessage);
    }
    
    private static void assignPassengerRoute(Train theTrain, int time){
        
    }
    
    private static void assignFreightRoute(Train theTrain, int time){
        int currentLoc,currentTime = time, endLoc = 0, index, bestValue;
        boolean currentLocHub,goodRoute = false, endLocHub = false;
        ArrayList<Integer> priorityValues = new ArrayList<>(), routeIdNums = new ArrayList<>();
        FreightRoute fRoute;
        Dtable dTable1, dTable2, dTable3;
        
        currentLoc = theTrain.getCurrentLoc();
        currentLocHub = theTrain.isCurrentLocHub();
        dTable1 = mainAlgorithm(theTrain,currentLoc,currentTime,currentLocHub,endLoc,endLocHub);
        for(int i = 0; i < allRoutes.getNumOfFreightRoutes(); i++){
            fRoute = allRoutes.getFreightByIndex(i);
            currentLoc = fRoute.getStartLocId();
            if(!dTable1.notVisited(currentLoc, false)){
                priorityValues.add(fRoute.getPriorityValue(dTable1.getTimeAtLoc(currentLoc, false), dTable1.getTimeAtLoc(currentLoc, false)- currentTime, 30));
                routeIdNums.add(fRoute.getRouteId());
            }
        }
        while(!goodRoute &&(priorityValues.size() > 0)){
            index = 0;
            bestValue = priorityValues.get(0);
            for(int j = 1; j< priorityValues.size();j++){
                if(priorityValues.get(j)<bestValue){
                    bestValue = priorityValues.get(j);
                    index = j;
                }
                fRoute = allRoutes.getFreightById(routeIdNums.get(j));
                currentTime = dTable1.getTimeAtLoc(currentLoc, false);
                if(currentTime < fRoute.getStartTime()){
                    currentTime = fRoute.getStartTime();
                }
                dTable2 = mainAlgorithm(theTrain,fRoute.getStartLocId(),currentTime,false,fRoute.getEndLocId(),false);
                
            }
        }
        
    }
    
    public static Tracks getAllTracks(){
        return allTracks;
    }
}
