/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trainsim;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Ryan
 */
public class Stations {
    private ArrayList<Station> allStations = new ArrayList<>();
    
    private Stations() {
    	
    }
    
    public Stations(ResultSet rs) throws SQLException{
        int i = 0;
        while(rs.next()){
            int stationID = rs.getInt("StationID");
            int freight = rs.getInt("Freight");
            int randomOnMin = rs.getInt("Random_On_Min");
            int randomOnMax = rs.getInt("Random_On_Max");
            int randomOffMin = rs.getInt("Random_Off_Min");
            int randomOffMax = rs.getInt("Random_Off_Max");
            int ticketPrice = rs.getInt("Ticket_Price");
            if(freight == 1){
                allStations.add(new Station(stationID,randomOnMin,randomOnMax,randomOffMin,randomOffMax,ticketPrice,true));
            }
            else{
                allStations.add(new Station(stationID,randomOnMin,randomOnMax,randomOffMin,randomOffMax,ticketPrice,false));
            }
            //System.out.println(allStations.get(i));
            i++;
        }
    }
    
    public Station getStationById(int id){
        for(int i =0; i<  allStations.size();i++){
            if(allStations.get(i).getStationID() == id){
                return allStations.get(i);
            }
        }
        return null;
    }
    
    public Station getStationByIndex(int index){
        if(index <= allStations.size()-1 && index >=0){
            return allStations.get(index);
        }
        return null;
    }
    
    public Stations getStationsByType(boolean Freight){
        Stations temp = new Stations();
        for(int i =0; i<  allStations.size();i++){
            if(allStations.get(i).getFreight() == Freight){
                temp.addStation(allStations.get(i));
            }
        }
        return temp;
    }
    
    private void addStation(Station s){
        allStations.add(s);
    }
    
    public int getSize(){
        return allStations.size();
    }
    
    public void deleteById(int id){
        for(int i =0; i<allStations.size();i++){
            if(allStations.get(i).getStationID()== id){
                allStations.remove(i);
            }
        }
    }
}
